package com.hema.expensetracker.repository;
import com.hema.expensetracker.entity.Category;
import java.util.Map;
import org.springframework.data.jpa.repository.Query;

import com.hema.expensetracker.entity.Expense;
import com.hema.expensetracker.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    List<Expense> findByUserId(int userId);
    @Query("SELECT COALESCE(SUM(e.amount),0) FROM Expense e WHERE e.user.id = :userId")
    double getTotalExpenseByUser(int userId);

    @Query("SELECT COUNT(e) FROM Expense e WHERE e.user.id = :userId")
    long getExpenseCountByUser(int userId);

    @Query("SELECT COALESCE(AVG(e.amount),0) FROM Expense e WHERE e.user.id = :userId")
    double getAverageExpenseByUser(int userId);
    
    List<Expense> findByUserIdAndCategory(int userId, Category category);
    @Query("""
    	       SELECT e.category, SUM(e.amount)
    	       FROM Expense e
    	       WHERE e.user.id = :userId
    	       GROUP BY e.category
    	       """)
    	List<Object[]> getCategorySummary(int userId);
    	@Query("""
    		       SELECT YEAR(e.expenseDate),
    		              MONTH(e.expenseDate),
    		              SUM(e.amount)
    		       FROM Expense e
    		       WHERE e.user.id = :userId
    		         AND e.expenseDate IS NOT NULL
    		       GROUP BY YEAR(e.expenseDate), MONTH(e.expenseDate)
    		       ORDER BY YEAR(e.expenseDate), MONTH(e.expenseDate)
    		       """)
    		List<Object[]> getMonthlySummary(int userId);
}
