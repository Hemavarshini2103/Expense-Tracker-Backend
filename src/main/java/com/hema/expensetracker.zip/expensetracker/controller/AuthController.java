package com.hema.expensetracker.controller;

import com.hema.expensetracker.dto.LoginRequest;
import com.hema.expensetracker.dto.LoginResponse;
import com.hema.expensetracker.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {

        String token = authService.login(request.getEmail(), request.getPassword());

        LoginResponse response = new LoginResponse();
        response.setToken(token);
        response.setMessage("Login successful");

        return response;
    }
}