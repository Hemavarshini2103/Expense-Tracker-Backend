package com.hema.expensetracker.controller;

import com.hema.expensetracker.dto.ExpenseResponse;
import com.hema.expensetracker.entity.Category;
import com.hema.expensetracker.entity.Expense;
import com.hema.expensetracker.service.ExpenseService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @PostMapping("/add")
    public ExpenseResponse addExpense(
            @Valid @RequestBody Expense expense) {

        return expenseService.addExpense(expense);
    }

    @PutMapping("/update/{id}")
    public Expense updateExpense(
            @PathVariable Long id,
            @RequestBody Expense expense) {

        return expenseService.updateExpense(id, expense);
    }

    @GetMapping("/my")
    public List<ExpenseResponse> getMyExpenses() {
        return expenseService.getExpensesByUser();
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        expenseService.deleteExpense(id);
        return "Expense deleted successfully";
    }

    @GetMapping("/total")
    public double total() {
        return expenseService.getTotalExpense();
    }

    @GetMapping("/count")
    public long count() {
        return expenseService.getExpenseCount();
    }

    @GetMapping("/average")
    public double average() {
        return expenseService.getAverageExpense();
    }

    @GetMapping("/category/{category}")
    public List<ExpenseResponse> byCategory(
            @PathVariable Category category) {

        return expenseService.getExpensesByCategory(category);
    }

    @GetMapping("/category-summary")
    public Map<Category, Double> categorySummary() {
        return expenseService.getCategorySummary();
    }

    @GetMapping("/monthly-summary")
    public Map<String, Double> monthlySummary() {
        return expenseService.getMonthlySummary();
    }
}