package com.hema.expensetracker.controller;

import com.hema.expensetracker.dto.BudgetRequest;
import com.hema.expensetracker.dto.BudgetResponse;
import com.hema.expensetracker.service.BudgetService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/budget")
public class BudgetController {

    @Autowired
    private BudgetService budgetService;

    @PostMapping("/set/{userId}")
    public String setBudget(
            @PathVariable int userId,
            @RequestBody BudgetRequest request) {

        budgetService.setBudget(userId, request);

        return "Budget set successfully";
    }

    @GetMapping("/status/{userId}")
    public BudgetResponse getBudgetStatus(
            @PathVariable int userId) {

        return budgetService.getBudgetStatus(userId);
    }
}