package com.hema.expensetracker.dto;

public class BudgetRequest {

    private double monthlyBudget;

    public BudgetRequest() {
    }

    public double getMonthlyBudget() {
        return monthlyBudget;
    }

    public void setMonthlyBudget(double monthlyBudget) {
        this.monthlyBudget = monthlyBudget;
    }
}