package com.hema.expensetracker.service;

import com.hema.expensetracker.dto.ExpenseResponse;
import com.hema.expensetracker.entity.*;
import com.hema.expensetracker.repository.*;
import com.hema.expensetracker.exception.ResourceNotFoundException;
import com.hema.expensetracker.util.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ExpenseServiceImpl implements ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    // GET USER FROM TOKEN
    private User getUser(String token) {

        String jwt = token.substring(7); // remove Bearer
        String email = jwtUtil.extractEmail(jwt); // FIXED

        return userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found"));
    }

    // ADD EXPENSE
    @Override
    public ExpenseResponse addExpense(String token, Expense expense) {

        User user = getUser(token);

        expense.setUser(user);

        Expense saved = expenseRepository.save(expense);

        return map(saved);
    }

    // GET EXPENSES
    @Override
    public List<ExpenseResponse> getExpensesByUser(String token) {

        User user = getUser(token);

        return expenseRepository.findByUserId(user.getId())
                .stream()
                .map(this::map)
                .collect(Collectors.toList());
    }

    @Override
    public double getTotalExpense(String token) {
        return expenseRepository.getTotalExpenseByUser(getUser(token).getId());
    }

    @Override
    public long getExpenseCount(String token) {
        return expenseRepository.getExpenseCountByUser(getUser(token).getId());
    }

    @Override
    public double getAverageExpense(String token) {
        return expenseRepository.getAverageExpenseByUser(getUser(token).getId());
    }

    @Override
    public List<ExpenseResponse> getExpensesByCategory(String token, Category category) {

        User user = getUser(token);

        return expenseRepository.findByUserIdAndCategory(user.getId(), category)
                .stream()
                .map(this::map)
                .collect(Collectors.toList());
    }

    @Override
    public Map<Category, Double> getCategorySummary(String token) {

        User user = getUser(token);

        List<Object[]> results = expenseRepository.getCategorySummary(user.getId());

        Map<Category, Double> map = new HashMap<>();

        for (Object[] row : results) {
            map.put((Category) row[0], ((Number) row[1]).doubleValue());
        }

        return map;
    }

    @Override
    public Map<String, Double> getMonthlySummary(String token) {

        User user = getUser(token);

        List<Object[]> results = expenseRepository.getMonthlySummary(user.getId());

        Map<String, Double> map = new LinkedHashMap<>();

        for (Object[] row : results) {

            Integer year = (Integer) row[0];
            Integer month = (Integer) row[1];
            Double total = ((Number) row[2]).doubleValue();

            map.put(year + "-" + String.format("%02d", month), total);
        }

        return map;
    }

    @Override
    public Expense updateExpense(Long id, Expense expense) {

        Expense existing = expenseRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Expense not found"));

        existing.setTitle(expense.getTitle());
        existing.setAmount(expense.getAmount());
        existing.setCategory(expense.getCategory());
        existing.setExpenseDate(expense.getExpenseDate());

        return expenseRepository.save(existing);
    }

    @Override
    public void deleteExpense(Long id) {
        expenseRepository.deleteById(id);
    }

    private ExpenseResponse map(Expense exp) {

        ExpenseResponse res = new ExpenseResponse();
        res.setId(exp.getId());
        res.setTitle(exp.getTitle());
        res.setAmount(exp.getAmount());
        res.setUserId(exp.getUser().getId());
        res.setCategory(exp.getCategory());
        res.setExpenseDate(exp.getExpenseDate());
        return res;
    }
}